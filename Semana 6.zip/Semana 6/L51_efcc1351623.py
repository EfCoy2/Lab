print("Ejercicio 1")

v1 = int(input("Ingrese un nùmero entero: "))

print("RESULTADO:")
if v1 > 0:
    print("Positivo")
if v1 < 0:
    print("Negativo")
if v1 == 0:
    print("Cero")