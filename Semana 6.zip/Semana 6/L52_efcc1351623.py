print("Ejercicio 2:")
v1 = int(input("Ingrese el dìa de la semana: "))

if 0 >= v1 or 8 >= v1:
    print("Error. El nùmero a ingresar debe estar contenido entre 1 y 7")


if v1 == 1:
    print("DIA:")
    print("lunes")
if v1 == 2:
    print("DIA:")
    print("martes")
if v1 == 3:
    print("DIA:")
    print("mièrcoles")
if v1 == 4:
    print("DIA:")
    print("jueves")
if v1 == 5:
    print("DIA:")
    print("viernes")
if v1 == 6:
    print("DIA:")
    print("sàbado")
if v1 == 7:
    print("DIA:")
    print("domingo")