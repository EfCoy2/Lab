'''variable1 = 0
print(variable1)
print (type (variable1), end="")
variable1 = "Hola"
print(variable1)
print (type (variable1), end="")
variable2 = True
print(variable2)
print (type (variable2), end="")
variable3 = False
print(variable3)
print (type (variable3), end="")
print("Hola Mundo soy Erick")'''

'''print("Hola Mundo")
print("soy Erick")

print("Hola Mundo", end="")
print(" soy Erick", end="")'''

'''el print normal solo imprime el texto individualmente mientras que con end los textos se unen'''


'''texto = input()
print(texto + " Hola")'''

texto2 = input()
print("Hola Mundo ", end="")
print("soy " + texto2)

print("Hola Mundo")
print("soy " + texto2)